package br.com.lab0102.sistema_de_aluguel_de_veiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDeAluguelDeVeiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
