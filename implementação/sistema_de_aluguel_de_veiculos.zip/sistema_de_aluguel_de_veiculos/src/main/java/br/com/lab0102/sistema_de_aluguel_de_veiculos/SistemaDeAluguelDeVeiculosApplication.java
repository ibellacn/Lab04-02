package br.com.lab0102.sistema_de_aluguel_de_veiculos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeAluguelDeVeiculosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeAluguelDeVeiculosApplication.class, args);
	}

}
